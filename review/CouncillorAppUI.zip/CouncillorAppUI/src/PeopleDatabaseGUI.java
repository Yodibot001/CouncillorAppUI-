import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class PeopleDatabaseGUI extends JFrame {
    private JButton captureButton, editButton, deleteButton, viewButton;
    private JList<String> peopleList;
    private DefaultListModel<String> listModel;

    private Connection connection;
    private Statement statement;

    public PeopleDatabaseGUI() {
        initializeUI();
        initializeDatabase();
    }

    private void initializeUI() {
        // Frame setup
        setTitle("People Database");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        // Buttons
        captureButton = new JButton("Capture");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        viewButton = new JButton("View");

        // List
        listModel = new DefaultListModel<>();
        peopleList = new JList<>(listModel);

        // Layout setup
        setLayout(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(captureButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);

        add(buttonPanel, BorderLayout.NORTH);
        add(new JScrollPane(peopleList), BorderLayout.CENTER);

        // Button actions
        captureButton.addActionListener(e -> captureData());
        editButton.addActionListener(e -> editData());
        deleteButton.addActionListener(e -> deleteData());
        viewButton.addActionListener(e -> viewData());
    }

    private void initializeDatabase() {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            String url = "jdbc:mysql://localhost:3306/people_db";
            String username = "root";
            String password = "password";
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void captureData() {
    String firstName = JOptionPane.showInputDialog("Enter First Name:");
    String lastName = JOptionPane.showInputDialog("Enter Last Name:");
    String address = JOptionPane.showInputDialog("Enter Address:");
    String phoneNumber = JOptionPane.showInputDialog("Enter Phone Number:");
    String reasonForVisit = JOptionPane.showInputDialog("Enter Reason for Visit:");

    try {
        // Create a PreparedStatement to avoid SQL injection
        String query = "INSERT INTO people_records (first_name, last_name, address, phone_number, reason_for_visit) " +
                       "VALUES (?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, firstName);
        preparedStatement.setString(2, lastName);
        preparedStatement.setString(3, address);
        preparedStatement.setString(4, phoneNumber);
        preparedStatement.setString(5, reasonForVisit);

        // Execute the update
        preparedStatement.executeUpdate();

        // Update the JList
        viewData();

        JOptionPane.showMessageDialog(this, "Data captured and added to the database.");

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error capturing data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    

    private void editData() {
    // Get the selected item from the JList
    int selectedIndex = peopleList.getSelectedIndex();

    if (selectedIndex == -1) {
        JOptionPane.showMessageDialog(this, "Please select a record to edit.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String selectedName = listModel.getElementAt(selectedIndex);

    // Split the selected name into first name and last name
    String[] names = selectedName.split("\\s");
    String selectedFirstName = names[0];
    String selectedLastName = names[1];

    // Prompt the user for new values
    String newFirstName = JOptionPane.showInputDialog("Enter New First Name:", selectedFirstName);
    String newLastName = JOptionPane.showInputDialog("Enter New Last Name:", selectedLastName);
    String newAddress = JOptionPane.showInputDialog("Enter New Address:");
    String newPhoneNumber = JOptionPane.showInputDialog("Enter New Phone Number:");
    String newReasonForVisit = JOptionPane.showInputDialog("Enter New Reason for Visit:");

    try {
        // Create a PreparedStatement to update the data
        String query = "UPDATE people_records SET first_name=?, last_name=?, address=?, phone_number=?, reason_for_visit=? " +
                       "WHERE first_name=? AND last_name=?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, newFirstName);
        preparedStatement.setString(2, newLastName);
        preparedStatement.setString(3, newAddress);
        preparedStatement.setString(4, newPhoneNumber);
        preparedStatement.setString(5, newReasonForVisit);
        preparedStatement.setString(6, selectedFirstName);
        preparedStatement.setString(7, selectedLastName);

        // Execute the update
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected > 0) {
            // Update the JList
            viewData();
            JOptionPane.showMessageDialog(this, "Data updated successfully.");
        } else {
            JOptionPane.showMessageDialog(this, "No matching record found for editing.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error editing data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    private void deleteData() {
    // Get the selected item from the JList
    int selectedIndex = peopleList.getSelectedIndex();

    if (selectedIndex == -1) {
        JOptionPane.showMessageDialog(this, "Please select a record to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String selectedName = listModel.getElementAt(selectedIndex);

    // Split the selected name into first name and last name
    String[] names = selectedName.split("\\s");
    String selectedFirstName = names[0];
    String selectedLastName = names[1];

    int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the selected record?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

    if (option == JOptionPane.YES_OPTION) {
        try {
            // Create a PreparedStatement to delete the data
            String query = "DELETE FROM people_records WHERE first_name=? AND last_name=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, selectedFirstName);
            preparedStatement.setString(2, selectedLastName);

            // Execute the delete
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                // Update the JList
                viewData();
                JOptionPane.showMessageDialog(this, "Record deleted successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "No matching record found for deletion.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
private void viewData() {
    try {
        listModel.clear();

        // Create a PreparedStatement to retrieve data
        String query = "SELECT * FROM people_records";
        PreparedStatement preparedStatement = connection.prepareStatement(query);

        // Execute the query
        ResultSet resultSet = preparedStatement.executeQuery();

        // Iterate through the result set and update the JList
        while (resultSet.next()) {
            String firstName = resultSet.getString("first_name");
            String lastName = resultSet.getString("last_name");
            listModel.addElement(firstName + " " + lastName);
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error retrieving data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


   
    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PeopleDatabaseGUI peopleDatabaseGUI = new PeopleDatabaseGUI();
            peopleDatabaseGUI.setVisible(true);
        });
    }
}
