import javax.swing.JFrame;

public class MainFrame extends JFrame {
    // Constructor and GUI components go here
}
