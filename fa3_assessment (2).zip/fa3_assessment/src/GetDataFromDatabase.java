import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetDataFromDatabase {
    public static void main(String[] args) {
        Connection connection = DatabaseConnection.getConnection();
        if (connection != null) {
            try {
                String query = "SELECT * FROM student_booking"; // Replace with your SQL query
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    // Retrieve data from the result set
                    String name = resultSet.getString("name");
                    String email = resultSet.getString("email");
                    String subject = resultSet.getString("subject");
                    String surname = resultSet.getString("surname");
                    String phone = resultSet.getString("phone");

                    // Do something with the retrieved data
                    System.out.println(name + ", " + email + ", " + subject + ", " + surname + ", " + phone);
                }

                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                DatabaseConnection.closeConnection(connection);
            }
        }
    }
}
