import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentApp extends JFrame {
    private JTextField txtName, txtEmail, txtSubject, txtSurname, txtPhone;
    private JButton btnInsert, btnView, btnExit;
    private JTable dataTable;
    private DefaultTableModel tableModel;

    public StudentApp() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Student Management App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(5, 2));

        inputPanel.add(new JLabel("Name:"));
        txtName = new JTextField();
        inputPanel.add(txtName);

        inputPanel.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        inputPanel.add(txtEmail);

        inputPanel.add(new JLabel("Subject:"));
        txtSubject = new JTextField();
        inputPanel.add(txtSubject);

        inputPanel.add(new JLabel("Surname:"));
        txtSurname = new JTextField();
        inputPanel.add(txtSurname);

        inputPanel.add(new JLabel("Phone:"));
        txtPhone = new JTextField();
        inputPanel.add(txtPhone);

        btnInsert = new JButton("Insert");
        btnInsert.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                insertData();
            }
        });

        btnView = new JButton("View");
        btnView.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                viewData();
            }
        });

        btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                System.exit(0);
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnInsert);
        buttonPanel.add(btnView);
        buttonPanel.add(btnExit);

        add(inputPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Name");
        tableModel.addColumn("Email");
        tableModel.addColumn("Subject");
        tableModel.addColumn("Surname");
        tableModel.addColumn("Phone");

        dataTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(dataTable);
        add(tableScrollPane, BorderLayout.CENTER);

        add(buttonPanel, BorderLayout.SOUTH);

        pack();
    }

    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/fa3_assessment";
        String user = "root";
        String password = "password";
        return DriverManager.getConnection(url, user, password);
    }

    private void insertData() {
        try (Connection connection = connectToDatabase();
             Statement statement = connection.createStatement()) {

            String name = txtName.getText();
            String email = txtEmail.getText();
            String subject = txtSubject.getText();
            String surname = txtSurname.getText();
            String phone = txtPhone.getText();

            String query = "INSERT INTO student_booking (name, email, subject, surname, phone) " +
                    "VALUES ('" + name + "', '" + email + "', '" + subject + "', '" + surname + "', '" + phone + "')";

            statement.executeUpdate(query);

            JOptionPane.showMessageDialog(this, "Data inserted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void viewData() {
        tableModel.setRowCount(0); // Clear existing data

        try (Connection connection = connectToDatabase();
             Statement statement = connection.createStatement()) {

            String query = "SELECT name, email, subject, surname, phone FROM student_booking";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String subject = resultSet.getString("subject");
                String surname = resultSet.getString("surname");
                String phone = resultSet.getString("phone");

                tableModel.addRow(new Object[]{name, email, subject, surname, phone});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new StudentApp().setVisible(true);
            }
        });
    }
}
