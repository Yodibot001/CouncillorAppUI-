import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CashRegisterApp extends JFrame {
    private JComboBox<String> chipsComboBox;
    private JComboBox<String> fishComboBox;
    private JCheckBox coolDrinkCheckBox;
    private JCheckBox rollCheckBox;
    private JTextField chipsQtyTextField;
    private JTextField fishQtyTextField;
    private JTextField amountPaidTextField;
    private JTextField changeAmountTextField;
    private JTextField totalTextField;
    private JButton processButton;

    private final double SNOEK_PRICE = 40.0;
    private final double HAKE_PRICE = 45.0;
    private final double SMALL_CHIPS_PRICE = 15.0;
    private final double MEDIUM_CHIPS_PRICE = 20.0;
    private final double LARGE_CHIPS_PRICE = 25.0;
    private final double ROLL_PRICE = 2.5;
    private final double COOL_DRINK_PRICE = 10.0;

    public CashRegisterApp() {
        setTitle("Fish and Chips Tuck Shop");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(9, 2, 10, 10));
        
        chipsComboBox = new JComboBox<>(new String[]{"Small", "Medium", "Large"});
        fishComboBox = new JComboBox<>(new String[]{"Snoek", "Hake"});
        coolDrinkCheckBox = new JCheckBox("Cool Drink");
        rollCheckBox = new JCheckBox("Roll");
        chipsQtyTextField = new JTextField();
        fishQtyTextField = new JTextField();
        amountPaidTextField = new JTextField();
        changeAmountTextField = new JTextField();
        totalTextField = new JTextField();
        processButton = new JButton("Process");
        
        processButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateTotalAndChange();
            }
        });

        add(new JLabel("Chips Size:"));
        add(chipsComboBox);
        add(new JLabel("Fish Type:"));
        add(fishComboBox);
        add(new JLabel("Chips Quantity:"));
        add(chipsQtyTextField);
        add(new JLabel("Fish Quantity:"));
        add(fishQtyTextField);
        add(new JLabel("Cool Drink:"));
        add(coolDrinkCheckBox);
        add(new JLabel("Roll:"));
        add(rollCheckBox);
        add(new JLabel("Amount Paid:"));
        add(amountPaidTextField);
        add(new JLabel("Change Amount:"));
        add(changeAmountTextField);
        add(new JLabel("Total:"));
        add(totalTextField);
        add(new JLabel(""));
        add(processButton);

        pack();
        setLocationRelativeTo(null);
    }

    private void calculateTotalAndChange() {
        double total = 0.0;

        String selectedChipsSize = (String) chipsComboBox.getSelectedItem();
        String selectedFishType = (String) fishComboBox.getSelectedItem();
        int chipsQty = Integer.parseInt(chipsQtyTextField.getText());
        int fishQty = Integer.parseInt(fishQtyTextField.getText());
        double amountPaid = Double.parseDouble(amountPaidTextField.getText());

        if (selectedChipsSize.equals("Small")) {
            total += SMALL_CHIPS_PRICE * chipsQty;
        } else if (selectedChipsSize.equals("Medium")) {
            total += MEDIUM_CHIPS_PRICE * chipsQty;
        } else if (selectedChipsSize.equals("Large")) {
            total += LARGE_CHIPS_PRICE * chipsQty;
        }

        if (selectedFishType.equals("Snoek")) {
            total += SNOEK_PRICE * fishQty;
        } else if (selectedFishType.equals("Hake")) {
            total += HAKE_PRICE * fishQty;
        }

        if (coolDrinkCheckBox.isSelected()) {
            total += COOL_DRINK_PRICE;
        }
        
        if (rollCheckBox.isSelected()) {
            total += ROLL_PRICE;
        }

        totalTextField.setText(String.format("%.2f", total));
        double changeAmount = amountPaid - total;
        changeAmountTextField.setText(String.format("%.2f", changeAmount));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CashRegisterApp().setVisible(true));
    }
}
